import React,{ Component } from 'react';
import './CajaChicaForm.css';

class CajaChicaForm extends Component {
    constructor(props) {
        super(props);

        let newDate = new Date(); 
        //let date = newDate.getDate();        
        let date = newDate.getFullYear() + '-' + (newDate.getMonth() + 1) + '-' + newDate.getDate();
        console.log('date: ' + date);

        const initialStateValues = {
            titleContainer: props.titleContainer,
            date: date,
            detail: "",
            tipoOperacion: "egreso",
            tipoCaja: "Bienes",
            amount : 0.00,
        };

        this.state = {                
            titleContainer: props.titleContainer,
            date: date,
            detail: "",
            tipoOperacion: "egreso",
            tipoCaja: "Bienes",
            amount : 0.00,
        };
        this.onClickCard = this.onClickCard.bind(this);   
        this.toggle = this.toggle.bind(this);
        this._handleKeyPress = this._handleKeyPress.bind(this);
        this.saveButton = this.saveButton.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        //this.handleKeyDown = this.handleKeyDown.bind(this);
    }

    onClickCard(file,fileTitle,fileContent,docId,event) {
        event.preventDefault();

        this.setState({
     
        });
        
        this.props.onClickCard(file, fileTitle, fileContent, docId);        
    }

    componentDidMount() {
        this.setState({
            titleContainer: "Caja Chica"          
        });

        // for (let x in this.refs) {
        //     this.refs[x].onkeypress = (e) =>    
        //       this._handleKeyPress(e, this.refs[x]);
        // }
        //this.refs.name.focus();
    }

    // bindRefsToKeypress() {
    //     for (let x in this.refs) {
    //         this.refs[x].onkeypress = (e) => 
    //           this.onKeyPressed(e, this.refs[x]);
    //       }
    // }
    
    onKeyPressed(field, e) {        
        if(e.key === 'Enter') {
            //e.preventDefault();
            console.log('Enter ref: ' + this.refs[e]);
            this.refs[e].focus();
        }

        // if (e.keyCode === 13) {
        //     e.preventDefault(); // Prevent form submission if button present
        //     let next = this.refs[field.name].nextSibling;
      
        //     if (next && next.tagName === "INPUT") {
        //       this.refs[field.name].nextSibling.focus();
        //     }
        // }
    }

    _handleKeyPress(e, field) {
        if (e.keyCode === 13) {
          e.preventDefault();

          try {
                let next = this.refs[field.name].nextSibling;
                if (next && next.tagName === "INPUT") {
                    console.log('Focus Input ' + this.refs[field.name] + '-' + this.refs[field.name].nextSibling);
                    this.refs[field.name].nextSibling.focus();
                }  
          }
          catch(e)
          {
              console.log('error on Keypress:' + e);
          }
        }
    }

    handleKeyDown(event) {
        console.log('event:' + event);
        if (event.keyCode === 13) {
            const form = event.target.form;
            const index = Array.prototype.indexOf.call(form, event.target);
            form.elements[index + 1].focus();
            event.preventDefault();
        }
    }

    handleInputChange = e => {
        console.log('name:' + e.target.name);
        const {name, value} = e.target;

        if(name = "fecha") {
            this.setState({date: e.target.value });   
        }
        else if(name == "detalle")
        {
            this.setState({detail: e.target.value });   
        }
        else if (name == "operacion")
        {
            this.setState({tipoOperacion: e.target.value });  
        }
        else if (name == "tipo")
        {
            this.setState({tipoCaja: e.target.value });  
        }                
        else if (name == "monto")
        {
            // this.setState({
            //     amount: e.target.value         
            // });   
            this.setState({amount: e.target.value });            
        }
    }

    saveButton(e) {
        e.preventDefault();
        alert("save Button");
    }

    // toggle = (type, value) => ({ key }) => {
    //     // [" ", "Enter"].includes(key) && dispatch({ type, value });    
    //     console.log('toggle:' + type + '-' + value);
    // }
    toggle(type, value) {        
        console.log('toggle:' + type + '-' + value);   
    }

    render() { 
        const { files } = this.props;        
        // const fields = files.map((field, index) =>                                        
        //                    <TextFile                                 
        //                         fileTitle={field.fileTitle} 
        //                         fileContent={field.fileContent} 
        //                         fileId={field.fileId}
        //                         docId={field.docId}
        //                         key={field.fileId} {...field}
        //                         viewLink= {"/text/" + field.fileId}
        //                         onClickCard = {this.onClickCard.bind(this,field.fileId, field.fileTitle, field.fileContent, field.docId)}
        //                    />)

        return ( 
            <div className="cajachica-content">    
                {/* {fields} */}
                <div className="box-date">
                    <div className="label-fecha">
                        <label htmlFor="lb-fecha">Fecha</label>
                    </div>
                    <input tabindex="-1" type="date" name="fecha" ref='fecha' value={this.date} />
                </div>
                {/* <input type="date" name="cumpleanios" step="1" min="2013-01-01" max="2013-12-31" value="2013-01-01"/> */}
                <div className="box-detalle">
                    <div className="dlv-detalle">
                        <label htmlFor="lb-detalle" className="lb-detalle">Detalle</label>
                    </div>                    
                    <input type="text" name="detalle" tabIndex="0" text="Detalle" placeholder="Detalle" onChange={this.handleInputChange} value={this.state.detail}  ref='detalle'/>
                </div>
                
                <div className="box-tipo-operacion">
                    <p>Tipo de Operacion</p>
                    <span className="tipo-operacion" ref='tipo-operacion'>
                        <input type="radio" id="ingreso" name="operacion" tabIndex="1"  ref='ingreso' value="ingreso"/>
                        <label htmlFor="ingreso">Ingreso</label>
                        <span className="tipo-operacion-space"/>
                        <input type="radio" id="egreso" name="operacion"  tabIndex="2" ref='egreso' value="egreso" checked />
                        <label htmlFor="egreso">Egreso</label>
                    </span>
                </div>                

                <div className="box-tipo-caja">
                    <p>Seleccione el tipo de caja</p>
                    <span>
                        <input type="radio" id="bienes" name="tipo" value="bienes" tabIndex="3"  ref='bienes' checked />
                        <label htmlFor="bienes">Bienes</label>
                    </span>
                    <span>
                        <input type="radio" id="servicios" name="tipo" value="servicios" tabIndex="4" ref='servicios' />
                        <label htmlFor="servicios">Servicios</label>
                    </span>
                    <span>
                        <input type="radio" id="resto" name="tipo" value="resto" tabIndex="5" ref='resto' />
                        <label htmlFor="resto">Resto</label>
                    </span>
                    <span>
                        <input type="radio" id="nc" name="tipo" value="nc" tabIndex="6" ref='nc' />
                        <label htmlFor="nc">No Corresponde</label>
                    </span>
                </div>

                <div className="monto-io">
                    <label htmlFor="lb-importe">Importe</label>
                    <input type="number" id="monto" name="monto" tabIndex="7" onChange={ this.handleInputChange }  value={this.state.amount} step="1"  ref='monto'/>
                </div>

                <div className="save-button">
                    <button type="button" id="saveButton" className="saveButton" onClick={this.saveButton} tabIndex="8"  ref='saveButton'>Save</button>
                </div>
            </div>
         );
    }
}
 
export default CajaChicaForm;